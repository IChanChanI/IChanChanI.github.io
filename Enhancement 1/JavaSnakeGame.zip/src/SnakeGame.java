import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;

public class SnakeGame extends JPanel implements ActionListener {
    static final int WIDTH = 400;
    static final int HEIGHT = 400;
    static final int BOX_SIZE = 20;

    boolean gameover;
    boolean paused;
    int score;
    int x, y, fruitX, fruitY, nTail;
    int[] tailX = new int[100];
    int[] tailY = new int[100];
    int delay;
    //Directions and keys
    enum Direction { STOP, LEFT, RIGHT, UP, DOWN }
    Direction dir;

    public SnakeGame() {
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.DARK_GRAY);
        this.setFocusable(true);
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_A:
                        if (dir != Direction.RIGHT) dir = Direction.LEFT;
                        break;
                    case KeyEvent.VK_D:
                        if (dir != Direction.LEFT) dir = Direction.RIGHT;
                        break;
                    case KeyEvent.VK_W:
                        if (dir != Direction.DOWN) dir = Direction.UP;
                        break;
                    case KeyEvent.VK_S:
                        if (dir != Direction.UP) dir = Direction.DOWN;
                        break;
                    case KeyEvent.VK_X:
                        gameover = true;
                        break;
                    case KeyEvent.VK_P:
                        paused = !paused;
                        break;
                }
            }
        });

        // Difficulty Selection
        String[] options = {"Easy", "Hard"};
        int choice = JOptionPane.showOptionDialog(null, "Please choose your level of difficulty", "Difficulty Level",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        //Differences between easy and hard is speed.
        if (choice == 0) {
            delay = 180; //slower pace game for easy
        } else {
            delay = 85; //Harder to control for hard level
        }

        setup();
        Timer timer = new Timer(delay, this);
        timer.start();
    }

    public void setup() {
        gameover = false;
        paused = false;
        dir = Direction.STOP;
        x = WIDTH / 2 / BOX_SIZE;
        y = HEIGHT / 2 / BOX_SIZE;
        spawnFruit();
        score = 0;
        nTail = 0;
    }
        //Fruit spawning random
    public void spawnFruit() {
        Random rand = new Random();
        fruitX = rand.nextInt(WIDTH / BOX_SIZE);
        fruitY = rand.nextInt(HEIGHT / BOX_SIZE);
    }
    //Main text and color customization
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (gameover) {
            g.setColor(Color.RED);
            g.drawString("GAME OVER", WIDTH / 2 - 30, HEIGHT / 2);
            g.drawString("Your Score Was: " + score, (WIDTH - g.getFontMetrics().stringWidth("Your Score Was: " + score)) / 2, HEIGHT / 2 + 20);
        } else {
            g.setColor(Color.WHITE);
            g.fillRect(x * BOX_SIZE, y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            for (int i = 0; i < nTail; i++) {
                g.fillRect(tailX[i] * BOX_SIZE, tailY[i] * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            }
            g.setColor(Color.GREEN);
            g.fillRect(fruitX * BOX_SIZE, fruitY * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            g.setColor(Color.YELLOW);
            g.drawString("Score: " + score, 10, 20);
            if (paused) {
                g.setColor(Color.YELLOW);
                g.drawString("Game is paused. Press 'P' to resume :)", (WIDTH - g.getFontMetrics().stringWidth("Game is paused. Press 'P' to resume :)")) / 2, HEIGHT / 2);

            }
        }
    }

    public void move() {
        if (paused) return;

        int prevX = tailX[0];
        int prevY = tailY[0];
        int prev2X, prev2Y;
        tailX[0] = x;
        tailY[0] = y;

        for (int i = 1; i < nTail; i++) {
            prev2X = tailX[i];
            prev2Y = tailY[i];
            tailX[i] = prevX;
            tailY[i] = prevY;
            prevX = prev2X;
            prevY = prev2Y;
        }

        switch (dir) {
            case LEFT: x--; break;
            case RIGHT: x++; break;
            case UP: y--; break;
            case DOWN: y++; break;
        }

        // Snake wrapping around the box
        if (x >= WIDTH / BOX_SIZE) x = 0;
        else if (x < 0) x = WIDTH / BOX_SIZE - 1;
        if (y >= HEIGHT / BOX_SIZE) y = 0;
        else if (y < 0) y = HEIGHT / BOX_SIZE - 1;

        // Checks collioson on itself
        for (int i = 0; i < nTail; i++) {
            if (tailX[i] == x && tailY[i] == y) {
                gameover = true;
            }
        }

        // Snake going over the fruit
        if (x == fruitX && y == fruitY) {
            score += 10;
            spawnFruit();
            nTail++;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        SnakeGame snakeGame = new SnakeGame();
        frame.add(snakeGame);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
